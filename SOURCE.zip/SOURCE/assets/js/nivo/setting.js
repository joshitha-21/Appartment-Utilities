    $(window).load(function() {
        $('#slider').nivoSlider();
    });