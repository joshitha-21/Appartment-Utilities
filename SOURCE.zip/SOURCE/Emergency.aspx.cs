﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["apptregstr"].ConnectionString);
    SqlCommand cmd = new SqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //TextBox1.Text = "";
        try
        {
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

            mail.From = new MailAddress("cloudauthorityserver@gmail.com");
            mail.To.Add(TextBox1.Text);
            mail.Subject = "Emegency Scenario";
            mail.Body = ("Case:" + " " + TextBox2.Text + " " + " " + "Name" + TextBox5.Text + "Block:" + DropDownList2.Text + " Flat No:" + DropDownList3.Text);
            //mail.Body = ("Row Name:" + " " + DropDownList2.Text + " " + "System No:" + DropDownList3.Text);

            SmtpServer.Port = 587;
            SmtpServer.Credentials = new System.Net.NetworkCredential("cloudauthorityserver@gmail.com", "cloud12345");
            SmtpServer.EnableSsl = true;

            SmtpServer.Send(mail);

        }
        catch (Exception ex)
        {
            Label1.Text = ex.ToString();

        }
        con1.Open();
        cmd = new SqlCommand("insert into Emergency values('" + DropDownList1.SelectedItem + "','" + TextBox1.Text + "','" + TextBox5.Text + "','" + TextBox2.Text + "','" + DropDownList2.SelectedItem + "','" + DropDownList3.SelectedItem + "')", con1);
        cmd.ExecuteNonQuery();

        Response.Write("<script>alert('Emergency Alert Registered Successfully...');</script>");
        con1.Close();
    }
}