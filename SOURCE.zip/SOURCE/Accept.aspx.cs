﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["apptregstr"].ConnectionString);
    SqlCommand cm = new SqlCommand();
    string a = "Accepted";
    protected void Page_Load(object sender, EventArgs e)
 {
     //TextBox1.Text = HttpUtility.UrlDecode(Request.QueryString["Name"]);
     TextBox2.Text = HttpUtility.UrlDecode(Request.QueryString["Mail"]);
     try
     {
         MailMessage mail = new MailMessage();
         SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

         mail.From = new MailAddress("cloudauthorityserver@gmail.com");
         mail.To.Add(TextBox2.Text);
         mail.Subject ="Complaint Regarding";
        mail.Body=("Your Requested Problem Will Solve Shotly."+" "+"Thank You.");
         //mail.Body = ("Row Name:" + " " + DropDownList2.Text + " " + "System No:" + DropDownList3.Text);

         SmtpServer.Port = 587;
         SmtpServer.Credentials = new System.Net.NetworkCredential("cloudauthorityserver@gmail.com", "cloud12345");
         SmtpServer.EnableSsl = true;

         SmtpServer.Send(mail);

     }
     catch (Exception ex)
     {
         Label1.Text = ex.ToString();

     }

        con.Open();
        cm = new SqlCommand("update RegComp set Status='"+a+"' where Mail='"+TextBox2.Text+"'",con);
        cm.ExecuteNonQuery();
        Response.Write("<script>alert('Request Accepted Successfully...');</script>");
        con.Close();
        Response.Redirect("SupportMenu.aspx");
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
}