﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["apptregstr"].ConnectionString);

        string labl = Session["Name"].ToString();
        
        string str = "SELECT * FROM Bill where Name='"+labl+"'";
        SqlDataAdapter adp = new SqlDataAdapter(str, con);
        DataSet set1 = new DataSet();
        adp.Fill(set1);
        GridView1.DataSource = set1.Tables[0];
        GridView1.DataBind();
        
    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}