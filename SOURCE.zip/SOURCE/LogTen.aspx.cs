﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Default4 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["apptregstr"].ConnectionString);
    SqlCommand cm = new SqlCommand();
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["Name"] = TextBox1.Text;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        cm = new SqlCommand("select uname,pwd from UserReg where uname='" + TextBox1.Text + "' and pwd='" + TextBox2.Text + "'", con);
        dr = cm.ExecuteReader();
        if (dr.Read())
        {

            Response.Redirect("TenantMenu.aspx");
        }
        else
        {
            Response.Write("<script>alert('Login Failed...');</script>");
        }
    }
}