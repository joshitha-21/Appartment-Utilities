﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

using System.Net.Mail;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["apptregstr"].ConnectionString);
    SqlCommand cmd = new SqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

            mail.From = new MailAddress("cloudauthorityserver@gmail.com");
            mail.To.Add(TextBox1.Text);
            mail.Subject = TextBox2.Text;
            mail.Body = ("block number:" + " " + DropDownList2.Text + " " + "flat id :" + DropDownList3.Text + "feedback :" + TextBox2.Text + " Thank you for your feedback");

            SmtpServer.Port = 587;
            SmtpServer.Credentials = new System.Net.NetworkCredential("cloudauthorityserver@gmail.com", "cloud12345");
            SmtpServer.EnableSsl = true;

            SmtpServer.Send(mail);

        }
        catch (Exception ex)
        {
            Label8.Text = ex.ToString();

        }
        con1.Open();
        cmd = new SqlCommand("insert into Feed values('" + DropDownList1.SelectedItem + "','" + TextBox1.Text + "','" + TextBox5.Text + "','" + TextBox2.Text + "','" + DropDownList2.SelectedItem + "','" + DropDownList3.SelectedItem + "')", con1);
        cmd.ExecuteNonQuery();

        Response.Write("<script>alert('Feedback Registered Successfully...');</script>");
        con1.Close();
    }

    protected void SqlDataSource2_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
}